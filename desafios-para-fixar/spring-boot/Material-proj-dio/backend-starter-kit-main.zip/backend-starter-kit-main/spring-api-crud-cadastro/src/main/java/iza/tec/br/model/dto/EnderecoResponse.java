package iza.tec.br.model.dto;

import lombok.Data;

@Data
public class EnderecoResponse extends EnderecoRequest{
    private Integer id;
}
