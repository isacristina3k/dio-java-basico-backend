package iza.tec.br.model.dto;

import lombok.Data;

@Data
public class PessoaResponse extends PessoaRequest{
    private Integer id;
}
