package com.proj_web.proj_java_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjJavaSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
