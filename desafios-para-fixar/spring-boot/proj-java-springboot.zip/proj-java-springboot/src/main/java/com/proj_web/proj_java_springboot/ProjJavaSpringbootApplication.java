package com.proj_web.proj_java_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjJavaSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjJavaSpringbootApplication.class, args);
	}

}
